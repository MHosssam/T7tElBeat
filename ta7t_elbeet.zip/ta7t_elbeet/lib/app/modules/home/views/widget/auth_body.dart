import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:ta7t_elbeet/app/data/ButtonData.dart';
import 'package:ta7t_elbeet/utilities/ColorsUtilities.dart';

class AuthBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Container(
            margin: EdgeInsets.only(top: 20),
            alignment: Alignment.center,
            width: Get.width,
            height: 500.h,
            child: Image.asset(
              'assets/images/logo.png',
              width: 500.h,
            )),
        ButtonData(
          text: 'تسجيل الدخول',
          color: ColorsUtilities.appBlue,
          onTap: (){},

        ),
      ],
    );
  }
}
