import 'package:flutter/material.dart';
import 'package:get/get.dart'; 
import 'package:ta7t_elbeet/app/modules/home/controllers/home_controller.dart';
import 'package:ta7t_elbeet/app/modules/home/views/widget/auth_body.dart';

class HomeView extends GetView<HomeController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AuthBody(),
      resizeToAvoidBottomPadding: false,
    );
  }
}
  