import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ColorsUtilities{

  static const Color appRed=Color(0xFFF24F46);
  static const Color appGreen=Color(0xFF68A65B);
  static const Color appWhite=Colors.white;
  static const Color appWhite70=Colors.white70;
  static  Color appGrey=Colors.grey[850];
  static  Color appGrey100=Colors.grey;
  static const Color appYellow=Color(0xFFfaa61a);
  static const Color appBlue = Color(0xff007dc5);



  static const String appFontFamily = 'cairo';

}