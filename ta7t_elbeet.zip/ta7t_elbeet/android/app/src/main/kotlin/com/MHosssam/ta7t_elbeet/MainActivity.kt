package com.MHosssam.ta7t_elbeet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
